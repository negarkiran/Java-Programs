package com.shopping;

import java.math.BigDecimal;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

public class ShoppingCartServiceTest {
	
	private ShoppingCart shoppingCart;
	
	private Product soap = new Product(1L, "Dove", new BigDecimal(39.99));
	
	@Before
	public  void init(){
		shoppingCart = new ShoppingCart();
	}
	
	@Test
	public void testProductsInShoppingCart(){
		//When  User adds 5 Dove Soaps
		shoppingCart.addProduct(soap, 5);
		
		//When  User adds 3 Dove Soaps
		shoppingCart.addProduct(soap, 3);
		
		//Then Shopping Cart should have 8 soaps
		Assert.assertEquals(8,shoppingCart.getProductsInCart().size());
		//Then the total price should be 199.95
		Assert.assertEquals(new BigDecimal("319.92"), shoppingCart.calculateTotal());
	}
	
}
