package com.shopping;

import java.math.BigDecimal;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

public class ShoppingCartServiceTest {
	
	private ShoppingCart shoppingCart;
	
	private Product soap = new Product(1L, "Dove", new BigDecimal(39.99));
	
	@Before
	public  void init(){
		shoppingCart = new ShoppingCart();
	}
	
	@Test
	public void testProductsInShoppingCart(){
		//When  User adds 5 Dove Soaps
		shoppingCart.addProduct(soap, 5);
		
		//Then Shopping Cart should have 5 soaps
		Assert.assertEquals(5,shoppingCart.getProductsInCart().size());
		//Then the total price should be 199.95
		Assert.assertEquals(new BigDecimal("199.95"), shoppingCart.calculateTotal());
	}
	
}
