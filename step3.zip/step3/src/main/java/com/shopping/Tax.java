package com.shopping;

import java.math.BigDecimal;

public class Tax {
	
	private Long id;
	private String name;
	private BigDecimal amount;
	
	public Tax(Long id, String name, BigDecimal amount) {
		this.id = id;
		this.name = name;
		this.amount = amount;
	}

	public BigDecimal getAmount() {
		return amount;
	}

	public Long getId() {
		return id;
	}

	public String getName() {
		return name;
	}
}
