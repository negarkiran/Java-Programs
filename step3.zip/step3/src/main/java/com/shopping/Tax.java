package com.shopping;

import java.math.BigDecimal;

public class Tax {
	
	private String type;
	private BigDecimal amount;
	
	public Tax(String type, BigDecimal amount) {
		this.type = type;
		this.amount = amount;
	}

	public BigDecimal getAmount() {
		return amount;
	}

	public String getType() {
		return type;
	}

}
