package com.shopping;

import java.math.BigDecimal;

public class Product {
	
	private Long id;
	private String name;
	private BigDecimal price;
	
	private Tax tax;
	
	Product(Long id,String name,BigDecimal price,Tax tax){
		this.id = id;
		this.name=name;
		this.price = price;
		this.tax = tax;
	}

	public Long getId() {
		return id;
	}

	public String getName() {
		return name;
	}
	
	public BigDecimal getPrice() {
		return price;
	}

	public Tax getTax() {
		return tax;
	}

}
