package com.shopping;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.IntStream;

public class ShoppingCart {

	private List<Product> products;
	
	public static final BigDecimal PERCENT = new BigDecimal("100");
	
	public ShoppingCart(){
		if(null==this.products){
			products = new ArrayList<>();
		}
	}
	
	public void addProduct(Product product,int quantity){
		IntStream.range(0, quantity).forEach(x->products.add(product));
	}
	
	public List<Product> getProductsInCart(){
		return products;
	}
	
	public BigDecimal calculateTotalWithoutTax(){
		return products.stream()
				.map(Product::getPrice)
				.reduce((x,y)->x.add(y).setScale(2,RoundingMode.HALF_EVEN)).get();
	}
	
	public BigDecimal calculateTotalTax(){
		BigDecimal totalTax = new BigDecimal("0");
		for(Product product : products){
			totalTax = totalTax.add(product.getTax().getAmount().multiply(product.getPrice()).divide(PERCENT).setScale(2,RoundingMode.HALF_EVEN));
		}
		return totalTax;
	}
	
	public BigDecimal shoppingCartTotal(){
		return calculateTotalWithoutTax().add(calculateTotalTax());
	}
	
}
