package com.shopping;

import java.math.BigDecimal;
import java.util.stream.Collectors;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

public class ShoppingCartServiceTest {
	
	private ShoppingCart shoppingCart;
	
	private Tax customerGoodsTax = new Tax("Customer Goods", new BigDecimal("12.5"));
	
	private Product soap = new Product(1L, "Dove Soap", new BigDecimal(39.99),customerGoodsTax);
	
	private Product deo = new Product(2L, "Axe Deo", new BigDecimal(99.99),customerGoodsTax);
	
	@Before
	public  void init(){
		shoppingCart = new ShoppingCart();
	}
	
	@Test
	public void testDoveSoapInShoppingCart(){
		//When  User adds 5 Dove Soaps
		shoppingCart.addProduct(soap, 5);
		
		//When  User adds 3 Dove Soaps
		shoppingCart.addProduct(soap, 3);
		
		//Then Shopping Cart should have 8 soaps
		Assert.assertEquals(8,shoppingCart.getProductsInCart().size());
		//Then the total price should be 199.95
		Assert.assertEquals(new BigDecimal("319.92"), shoppingCart.calculateTotalWithoutTax());
	}
	
	@Test
	public void testSoapAndDeoInShoppingCart(){
		//When  User adds 2 Dove Soaps
		shoppingCart.addProduct(soap, 2);
		
		//When  User adds 2 Dove Soaps
		shoppingCart.addProduct(deo, 2);
		
		//Then Shopping Cart should have 2 soaps
		Assert.assertEquals(2,shoppingCart.getProductsInCart()
				.stream().
				filter(product->product.getName().equalsIgnoreCase("Dove Soap"))
				.collect(Collectors.toList()).size());
		
		//Then Shopping Cart should have 2 deos
		Assert.assertEquals(2,shoppingCart.getProductsInCart()
				.stream().
				filter(product->product.getName().equalsIgnoreCase("Axe Deo"))
				.collect(Collectors.toList()).size());
		
		//Then the total tax amount is 35.00
		Assert.assertEquals(new BigDecimal("35.00"), shoppingCart.calculateTotalTax());
		
		//Then the total cart amount is 314.96
		Assert.assertEquals(new BigDecimal("314.96"), shoppingCart.shoppingCartTotal());
		
	}
	
}
